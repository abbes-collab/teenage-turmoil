
// Year
document.getElementById('year').textContent = new Date().getFullYear();

// Parallax on mouse
const parallax = document.querySelector('.parallax');
document.addEventListener('mousemove', (e) => {
  if(!parallax) return;
  const x = (e.clientX / window.innerWidth - 0.5) * 8;
  const y = (e.clientY / window.innerHeight - 0.5) * 8;
  parallax.style.transform = `translate(${x}px, ${y}px)`;
});

// Scroll reveal
const io = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add('visible');
      io.unobserve(entry.target);
    }
  })
},{threshold: .2});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));

// Tilt cards
document.querySelectorAll('.tilt').forEach(card => {
  card.addEventListener('mousemove', (e)=>{
    const r = card.getBoundingClientRect();
    const rx = ((e.clientY - r.top) / r.height - .5) * -12;
    const ry = ((e.clientX - r.left) / r.width - .5) * 12;
    card.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg) translateY(-2px)`;
  });
  card.addEventListener('mouseleave', ()=>{
    card.style.transform = '';
  });
});

// Fake subscribe
function thanks(){
  const input = document.getElementById('email');
  const email = input.value.trim();
  if(!email) return;
  alert('Thanks! You will get launch news soon.');
  input.value = '';
}

// Stars / particles canvas
(function(){
  const canvas = document.getElementById('stars');
  const ctx = canvas.getContext('2d');
  let w,h,particles;
  function resize(){ w=canvas.width=innerWidth; h=canvas.height=innerHeight; make(); }
  function make(){
    particles = Array.from({length: Math.min(220, Math.floor(w*h/9000))}, () => ({
      x: Math.random()*w,
      y: Math.random()*h,
      r: Math.random()*1.4 + .2,
      vx: (Math.random()-.5)*.08,
      vy: (Math.random()-.5)*.08,
      a: Math.random()*.6+.2,
    }));
  }
  function draw(){
    ctx.clearRect(0,0,w,h);
    particles.forEach(p=>{
      p.x+=p.vx; p.y+=p.vy;
      if(p.x<0) p.x=w; if(p.x>w) p.x=0; if(p.y<0) p.y=h; if(p.y>h) p.y=0;
      ctx.beginPath();
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle = `rgba(180,210,255,${p.a})`;
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }
  resize(); draw(); addEventListener('resize', resize);
})();
